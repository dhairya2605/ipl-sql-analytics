"""
01_clean_and_load.py

Loads the real IPL dataset (source: avinashyadav16/ipl-analytics, itself
derived from the Kaggle "IPL Complete Dataset 2008-2024" by patrickb1912)
into Postgres.

Real data quality issues found and fixed (documented for README):
  - deliveries.csv column headers have leading/trailing whitespace
    (' inning ', ' batting_team  ') from the source export — stripped here
  - 'NA' string literals used instead of true NULLs across both files —
    converted to proper NULL so aggregate functions don't silently miscount
  - method column is 98%+ null (DLS method only applies to rain-affected
    matches) — this is correct/expected, not a data error
  - team names changed over the competition's history (e.g. Delhi Daredevils
    -> Delhi Capitals, Kings XI Punjab -> Punjab Kings, Deccan Chargers ->
    Sunrisers Hyderabad) — NOT normalized here deliberately, kept as a
    documented analytical caveat (see README) since collapsing them changes
    what "team" means historically and franchises themselves don't treat
    the rebrand as continuity for records purposes
"""
import pandas as pd
import sqlalchemy as sa

DATA_DIR = "../data"
engine = sa.create_engine("postgresql+psycopg2://postgres:claude@localhost/ipl_analytics")

# ---------------------------------------------------------------------------
# Matches
# ---------------------------------------------------------------------------
matches = pd.read_csv(f"{DATA_DIR}/matches.csv")
matches.columns = [c.strip() for c in matches.columns]
matches = matches.replace({"NA": None})
matches["date"] = pd.to_datetime(matches["date"]).dt.date

# Fix a genuine data-entry inconsistency: 'Rising Pune Supergiant' vs
# 'Rising Pune Supergiants' are the SAME franchise (2016 vs 2017 seasons),
# just spelled inconsistently in the source export — not a real rebrand
# like Delhi Daredevils -> Delhi Capitals, so this one IS normalized.
TEAM_TYPO_FIX = {"Rising Pune Supergiant": "Rising Pune Supergiants"}
for col in ["team1", "team2", "toss_winner", "winner"]:
    matches[col] = matches[col].replace(TEAM_TYPO_FIX)

print(f"Matches: {len(matches):,} rows, {matches['season'].nunique()} seasons "
      f"({matches['season'].min()}-{matches['season'].max()})")

# ---------------------------------------------------------------------------
# Deliveries
# ---------------------------------------------------------------------------
deliveries = pd.read_csv(f"{DATA_DIR}/deliveries.csv")
deliveries.columns = [c.strip() for c in deliveries.columns]
for col in ["batting_team", "bowling_team", "batter", "bowler", "non_striker",
            "extras_type", "player_dismissed", "dismissal_kind", "fielder"]:
    deliveries[col] = deliveries[col].astype(str).str.strip()
deliveries = deliveries.replace({"NA": None, "nan": None})
for col in ["batting_team", "bowling_team"]:
    deliveries[col] = deliveries[col].replace(TEAM_TYPO_FIX)
print(f"Deliveries: {len(deliveries):,} rows")

# Sanity checks before load
orphan_matches = set(deliveries["match_id"]) - set(matches["id"])
print(f"Delivery rows referencing a non-existent match_id: "
      f"{deliveries['match_id'].isin(orphan_matches).sum()}")

matches.to_sql("matches", engine, if_exists="append", index=False)
deliveries.to_sql("deliveries", engine, if_exists="append", index=False, chunksize=5000)
print("Loaded matches and deliveries into Postgres.")
