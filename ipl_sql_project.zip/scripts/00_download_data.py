"""
00_download_data.py

deliveries.csv (~69MB, 260,920 rows) is too large to bundle in this zip
and shouldn't be committed to git. Run this once to download it directly
from the source GitHub repo before running 01_clean_and_load.py.
"""
import urllib.request
import os

URL = "https://raw.githubusercontent.com/avinashyadav16/ipl-analytics/main/deliveries_2008-2024.csv"
OUT_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "deliveries.csv")

print(f"Downloading deliveries.csv from {URL} ...")
urllib.request.urlretrieve(URL, OUT_PATH)
print(f"Saved to {OUT_PATH}")
