-- ============================================================================
-- queries.sql — IPL Analytics (2008-2024)
-- Real data: 1,095 matches, 260,920 deliveries
-- Source: Kaggle "IPL Complete Dataset 2008-2024" (patrickb1912), via
--         avinashyadav16/ipl-analytics GitHub mirror
--
-- NOTE ON TEAM NAMES: franchise renames (Delhi Daredevils -> Delhi Capitals,
-- Kings XI Punjab -> Punjab Kings, Deccan Chargers -> Sunrisers Hyderabad,
-- Royal Challengers Bangalore -> Royal Challengers Bengaluru) are kept
-- SEPARATE, not merged — these are genuinely different eras/identities in
-- IPL record-keeping. One genuine data-entry typo (Rising Pune Supergiant
-- vs Supergiants, same team) WAS fixed during loading — see
-- scripts/01_clean_and_load.py.
-- ============================================================================


-- ============================================================================
-- SECTION 1: LEAGUE OVERVIEW
-- ============================================================================

-- Q1. Total matches played
SELECT COUNT(*) AS total_matches FROM matches;

-- Q2. Matches per season (trend over time)
SELECT season, COUNT(*) AS total_matches
FROM matches GROUP BY season ORDER BY season;

-- Q3. Most successful teams by win count
SELECT winner, COUNT(*) AS matches_won
FROM matches
WHERE winner IS NOT NULL
GROUP BY winner ORDER BY matches_won DESC LIMIT 10;

-- Q4. Venues by number of matches hosted
SELECT venue, COUNT(*) AS no_of_matches
FROM matches GROUP BY venue ORDER BY no_of_matches DESC LIMIT 10;


-- ============================================================================
-- SECTION 2: BATTING ANALYSIS
-- ============================================================================

-- Q5. Boundary dependency % per batter (min 1000 career runs)
-- Business question: which batters rely heavily on boundaries vs rotating
-- strike for their runs — a real scouting/strategy metric.
SELECT
    batter,
    SUM(batsman_runs) AS total_runs,
    SUM(CASE WHEN batsman_runs IN (4,6) THEN batsman_runs ELSE 0 END) AS boundary_runs,
    ROUND(
        SUM(CASE WHEN batsman_runs IN (4,6) THEN batsman_runs ELSE 0 END)::NUMERIC
        / SUM(batsman_runs) * 100, 2
    ) AS boundary_dependency_pct
FROM deliveries
GROUP BY batter
HAVING SUM(batsman_runs) >= 1000
ORDER BY boundary_dependency_pct DESC
LIMIT 15;

-- Q6. Favorite opposition per batter (most runs scored against one team)
WITH batter_runs AS (
    SELECT d.batter,
           CASE WHEN d.batting_team = m.team1 THEN m.team2 ELSE m.team1 END AS opposition_team,
           SUM(d.batsman_runs) AS total_runs
    FROM deliveries d JOIN matches m ON d.match_id = m.id
    GROUP BY d.batter, opposition_team
),
ranked AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY batter ORDER BY total_runs DESC) AS rn
    FROM batter_runs
)
SELECT batter, opposition_team, total_runs FROM ranked WHERE rn = 1
ORDER BY total_runs DESC LIMIT 15;

-- Q7. Second-highest run scorer in IPL history (DENSE_RANK, not just OFFSET)
WITH ranked AS (
    SELECT batter, SUM(batsman_runs) AS total_runs,
           DENSE_RANK() OVER (ORDER BY SUM(batsman_runs) DESC) AS rnk
    FROM deliveries GROUP BY batter
)
SELECT batter, total_runs FROM ranked WHERE rnk = 2;

-- Q8. Top 10 batters by number of half-centuries (50-99 in a single innings)
WITH innings_runs AS (
    SELECT batter, match_id, inning, SUM(batsman_runs) AS runs
    FROM deliveries GROUP BY batter, match_id, inning
)
SELECT batter, COUNT(*) AS no_of_fifties
FROM innings_runs WHERE runs BETWEEN 50 AND 99
GROUP BY batter ORDER BY no_of_fifties DESC LIMIT 10;

-- Q9. Orange Cap winner per season (top run-scorer each year)
WITH orange_cap AS (
    SELECT m.season, d.batter, SUM(d.batsman_runs) AS total_runs,
           DENSE_RANK() OVER (PARTITION BY m.season ORDER BY SUM(d.batsman_runs) DESC) AS rnk
    FROM matches m JOIN deliveries d ON m.id = d.match_id
    GROUP BY m.season, d.batter
)
SELECT season, batter, total_runs FROM orange_cap WHERE rnk = 1 ORDER BY season;

-- Q10. Top 5 batting strike rates (min 500 career runs, excluding wides from balls faced)
SELECT
    batter,
    SUM(batsman_runs) AS total_runs,
    COUNT(*) FILTER (WHERE extras_type IS NULL OR extras_type != 'wides') AS balls_faced,
    ROUND(
        SUM(batsman_runs)::numeric
        / NULLIF(COUNT(*) FILTER (WHERE extras_type IS NULL OR extras_type != 'wides'), 0)
        * 100, 2
    ) AS strike_rate
FROM deliveries
GROUP BY batter
HAVING SUM(batsman_runs) >= 500
ORDER BY strike_rate DESC LIMIT 5;

-- Q11. Top 5 batting averages (min 20 dismissals, career)
SELECT
    batter,
    SUM(batsman_runs) AS total_runs,
    COUNT(*) FILTER (WHERE player_dismissed = batter) AS dismissals,
    ROUND(SUM(batsman_runs)::numeric / NULLIF(COUNT(*) FILTER (WHERE player_dismissed = batter), 0), 2) AS batting_average
FROM deliveries
GROUP BY batter
HAVING COUNT(*) FILTER (WHERE player_dismissed = batter) >= 20
ORDER BY batting_average DESC LIMIT 5;

-- Q12. Batters never dismissed for a duck (0 runs), min 10 innings played
-- (min-innings filter added — the original version would trivially include
--  one-match players who just never had the chance to fail)
WITH innings_stats AS (
    SELECT batter, match_id, inning,
           SUM(batsman_runs) AS runs,
           MAX(CASE WHEN player_dismissed = batter THEN 1 ELSE 0 END) AS got_out
    FROM deliveries GROUP BY batter, match_id, inning
),
batter_innings_count AS (
    SELECT batter, COUNT(*) AS innings_played FROM innings_stats GROUP BY batter
)
SELECT i1.batter, bic.innings_played
FROM innings_stats i1
JOIN batter_innings_count bic ON i1.batter = bic.batter
WHERE bic.innings_played >= 10
  AND NOT EXISTS (
      SELECT 1 FROM innings_stats i2
      WHERE i1.batter = i2.batter AND i2.runs = 0 AND i2.got_out = 1
  )
GROUP BY i1.batter, bic.innings_played
ORDER BY bic.innings_played DESC;


-- ============================================================================
-- SECTION 3: BOWLING & MATCH DYNAMICS
-- ============================================================================

-- Q13. Highest average 1st-innings score by venue (batting-friendly grounds)
WITH first_innings_score AS (
    SELECT match_id, SUM(total_runs) AS first_innings_total
    FROM deliveries WHERE inning = 1 GROUP BY match_id
)
SELECT m.venue,
       ROUND(AVG(fis.first_innings_total), 2) AS avg_first_innings_score,
       COUNT(*) AS matches_played
FROM first_innings_score fis JOIN matches m ON fis.match_id = m.id
GROUP BY m.venue HAVING COUNT(*) >= 5
ORDER BY avg_first_innings_score DESC LIMIT 10;

-- Q14. Bowler who has dismissed each batter the most times (bowler "bunny" pairs)
SELECT batter, bowler, COUNT(*) AS no_of_outs
FROM deliveries
WHERE dismissal_kind NOT IN ('run out', 'retired hurt') AND player_dismissed = batter
GROUP BY batter, bowler
ORDER BY no_of_outs DESC LIMIT 15;

-- Q15. Teams that defend totals best (batted first AND won)
WITH batting_first AS (
    SELECT
        CASE
            WHEN toss_winner = team1 AND toss_decision = 'bat' THEN team1
            WHEN toss_winner = team1 AND toss_decision = 'field' THEN team2
            WHEN toss_winner = team2 AND toss_decision = 'bat' THEN team2
            WHEN toss_winner = team2 AND toss_decision = 'field' THEN team1
        END AS batting_first_team,
        winner
    FROM matches WHERE winner IS NOT NULL
)
SELECT batting_first_team AS team,
       COUNT(*) AS matches_batted_first,
       SUM(CASE WHEN batting_first_team = winner THEN 1 ELSE 0 END) AS matches_defended,
       ROUND(100.0 * SUM(CASE WHEN batting_first_team = winner THEN 1 ELSE 0 END) / COUNT(*), 1) AS defend_success_rate_pct
FROM batting_first
GROUP BY batting_first_team
HAVING COUNT(*) >= 10
ORDER BY defend_success_rate_pct DESC;

-- Q16. 10 players with most Player of the Match awards
SELECT player_of_match, COUNT(*) AS awards
FROM matches WHERE player_of_match IS NOT NULL
GROUP BY player_of_match ORDER BY awards DESC LIMIT 10;

-- Q17. Teams that lost after scoring 200+ in their innings (upset losses)
-- (this was the incomplete query in the original draft — completed here)
-- Business question: how often does a big first-innings total NOT translate
-- to a win — signals how "unpredictable"/chaseable IPL scoring really is.
WITH innings_totals AS (
    SELECT match_id, inning, batting_team, SUM(total_runs) AS innings_score
    FROM deliveries GROUP BY match_id, inning, batting_team
)
SELECT it.batting_team AS team, it.match_id, it.inning, it.innings_score,
       m.winner, m.season, m.venue
FROM innings_totals it
JOIN matches m ON it.match_id = m.id
WHERE it.innings_score >= 200 AND it.batting_team != m.winner AND m.winner IS NOT NULL
ORDER BY it.innings_score DESC;


-- ============================================================================
-- SECTION 4: NEW ADDITIONS — toss impact, phase-wise scoring, chase success,
-- home advantage (all requested to round out the BA-framing of this project)
-- ============================================================================

-- Q18. Toss decision impact on match outcome, by decision type
-- Business question: does winning the toss and choosing to field actually
-- carry an advantage in IPL (this is a widely believed but rarely quantified claim)
SELECT toss_decision,
       COUNT(*) AS matches,
       COUNT(*) FILTER (WHERE toss_winner = winner) AS toss_winner_also_won,
       ROUND(100.0 * COUNT(*) FILTER (WHERE toss_winner = winner) / COUNT(*), 1) AS toss_winner_win_rate_pct
FROM matches
WHERE winner IS NOT NULL
GROUP BY toss_decision;

-- Q19. Toss decision trend by season (has the "always field first" meta shifted?)
SELECT season, toss_decision, COUNT(*) AS n_times_chosen,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (PARTITION BY season), 1) AS pct_of_season
FROM matches
GROUP BY season, toss_decision
ORDER BY season, n_times_chosen DESC;

-- Q20. Phase-wise scoring comparison across the league (powerplay vs middle vs death)
-- Uses vw_phase_wise_scoring — demonstrates the view being consumed directly,
-- exactly how Power BI would query it.
SELECT phase,
       ROUND(AVG(runs_scored), 2) AS avg_runs_per_innings_in_phase,
       ROUND(AVG(wickets_lost), 2) AS avg_wickets_lost_in_phase,
       ROUND(AVG(runs_scored)::numeric / (CASE WHEN phase = 'Powerplay (1-6)' THEN 6
                                               WHEN phase = 'Middle (7-15)' THEN 9
                                               ELSE 5 END), 2) AS avg_run_rate
FROM vw_phase_wise_scoring
GROUP BY phase;

-- Q21. Death-over run rate trend by season (has T20 hitting gotten more aggressive?)
SELECT season,
       ROUND(AVG(runs_scored)::numeric / 5, 2) AS avg_death_over_run_rate
FROM vw_phase_wise_scoring
WHERE phase = 'Death (16-20)'
GROUP BY season ORDER BY season;

-- Q22. Chase success rate by target range (how "gettable" are different targets?)
-- Business question: at what target size does chasing stop being reliably successful?
WITH chase_matches AS (
    SELECT m.id, m.target_runs, m.winner,
           CASE WHEN m.toss_winner = m.team1 AND m.toss_decision = 'field' THEN m.team1
                WHEN m.toss_winner = m.team2 AND m.toss_decision = 'field' THEN m.team2
                WHEN m.toss_winner = m.team1 AND m.toss_decision = 'bat' THEN m.team2
                WHEN m.toss_winner = m.team2 AND m.toss_decision = 'bat' THEN m.team1
           END AS chasing_team
    FROM matches m
    WHERE m.target_runs IS NOT NULL AND m.winner IS NOT NULL AND m.super_over = 'N'
)
SELECT
    CASE
        WHEN target_runs < 140 THEN 'Under 140'
        WHEN target_runs < 160 THEN '140-159'
        WHEN target_runs < 180 THEN '160-179'
        WHEN target_runs < 200 THEN '180-199'
        ELSE '200+'
    END AS target_range,
    COUNT(*) AS matches,
    COUNT(*) FILTER (WHERE chasing_team = winner) AS chase_successful,
    ROUND(100.0 * COUNT(*) FILTER (WHERE chasing_team = winner) / COUNT(*), 1) AS chase_success_rate_pct
FROM chase_matches
GROUP BY 1
ORDER BY MIN(target_runs);

-- Q23. Home advantage — win rate at a team's most-used home city vs elsewhere
-- Business question: does "home crowd" advantage actually show up in the data?
-- Home city defined as the city where a team has played the most matches
-- (a reasonable proxy since IPL doesn't have a single fixed home venue column).
WITH team_appearances AS (
    SELECT team1 AS team, city FROM matches WHERE city IS NOT NULL
    UNION ALL
    SELECT team2 AS team, city FROM matches WHERE city IS NOT NULL
),
home_city AS (
    SELECT DISTINCT ON (team) team, city AS home_city
    FROM (
        SELECT team, city, COUNT(*) AS n
        FROM team_appearances GROUP BY team, city
    ) t
    ORDER BY team, n DESC
),
team_matches AS (
    SELECT m.id, m.city, m.winner, m.team1 AS team FROM matches m WHERE m.winner IS NOT NULL
    UNION ALL
    SELECT m.id, m.city, m.winner, m.team2 AS team FROM matches m WHERE m.winner IS NOT NULL
)
SELECT
    tm.team,
    hc.home_city,
    COUNT(*) FILTER (WHERE tm.city = hc.home_city) AS home_matches,
    ROUND(100.0 * COUNT(*) FILTER (WHERE tm.city = hc.home_city AND tm.winner = tm.team)
        / NULLIF(COUNT(*) FILTER (WHERE tm.city = hc.home_city), 0), 1) AS home_win_pct,
    COUNT(*) FILTER (WHERE tm.city != hc.home_city) AS away_matches,
    ROUND(100.0 * COUNT(*) FILTER (WHERE tm.city != hc.home_city AND tm.winner = tm.team)
        / NULLIF(COUNT(*) FILTER (WHERE tm.city != hc.home_city), 0), 1) AS away_win_pct
FROM team_matches tm
JOIN home_city hc ON tm.team = hc.team
GROUP BY tm.team, hc.home_city
HAVING COUNT(*) FILTER (WHERE tm.city = hc.home_city) >= 10
ORDER BY home_win_pct DESC;

-- Q24. Season-over-season league scoring trend (has IPL scoring inflated over time?)
-- Good Power BI line-chart candidate.
WITH match_totals AS (
    SELECT match_id, SUM(total_runs) AS match_runs
    FROM deliveries GROUP BY match_id
)
SELECT m.season, ROUND(AVG(mt.match_runs), 1) AS avg_runs_per_match
FROM match_totals mt JOIN matches m ON mt.match_id = m.id
GROUP BY m.season ORDER BY m.season;

-- Q25. Extras (wides/no-balls/byes) conceded by bowling team, by season
-- A discipline/quality metric — real analysts track bowling extras as a
-- proxy for control, not just wickets/economy.
SELECT m.season, d.bowling_team,
       SUM(d.extra_runs) AS total_extras_conceded,
       COUNT(DISTINCT d.match_id) AS matches,
       ROUND(SUM(d.extra_runs)::numeric / COUNT(DISTINCT d.match_id), 2) AS avg_extras_per_match
FROM deliveries d JOIN matches m ON d.match_id = m.id
GROUP BY m.season, d.bowling_team
ORDER BY m.season, avg_extras_per_match DESC;
