-- ============================================================================
-- schema.sql — IPL Analytics
-- Source: real ball-by-ball data, 2008-2024 seasons (1,095 matches, 260,920
-- deliveries). See README for full data lineage and cleaning notes.
-- ============================================================================

DROP VIEW IF EXISTS vw_batter_season_stats CASCADE;
DROP VIEW IF EXISTS vw_team_season_summary CASCADE;
DROP VIEW IF EXISTS vw_match_summary CASCADE;
DROP VIEW IF EXISTS vw_phase_wise_scoring CASCADE;
DROP TABLE IF EXISTS deliveries CASCADE;
DROP TABLE IF EXISTS matches CASCADE;

CREATE TABLE matches (
    id INTEGER PRIMARY KEY,
    season VARCHAR(10),
    city VARCHAR(100),
    date DATE,
    match_type VARCHAR(30),
    player_of_match VARCHAR(100),
    venue VARCHAR(255),
    team1 VARCHAR(100),
    team2 VARCHAR(100),
    toss_winner VARCHAR(100),
    toss_decision VARCHAR(20),
    winner VARCHAR(100),
    result VARCHAR(20),
    result_margin INTEGER,
    target_runs INTEGER,
    target_overs NUMERIC(4,1),
    super_over VARCHAR(5),
    method VARCHAR(50),
    umpire1 VARCHAR(100),
    umpire2 VARCHAR(100)
);

CREATE TABLE deliveries (
    match_id INTEGER,
    inning INTEGER,
    batting_team VARCHAR(100),
    bowling_team VARCHAR(100),
    over INTEGER,
    ball INTEGER,
    batter VARCHAR(100),
    bowler VARCHAR(100),
    non_striker VARCHAR(100),
    batsman_runs INTEGER,
    extra_runs INTEGER,
    total_runs INTEGER,
    extras_type VARCHAR(50),
    is_wicket INTEGER,
    player_dismissed VARCHAR(100),
    dismissal_kind VARCHAR(50),
    fielder VARCHAR(100),
    CONSTRAINT fk_match FOREIGN KEY (match_id) REFERENCES matches(id)
);

-- Indexes — deliveries is the large table (260K+ rows) and gets filtered/
-- grouped by these columns constantly, so this is a real performance need,
-- not decoration
CREATE INDEX idx_deliveries_match ON deliveries(match_id);
CREATE INDEX idx_deliveries_batter ON deliveries(batter);
CREATE INDEX idx_deliveries_bowler ON deliveries(bowler);
CREATE INDEX idx_deliveries_batting_team ON deliveries(batting_team);
CREATE INDEX idx_matches_season ON matches(season);
CREATE INDEX idx_matches_winner ON matches(winner);

-- ============================================================================
-- VIEWS — built specifically so Power BI (or any BI tool) can connect
-- directly to a clean, pre-aggregated table instead of raw ball-by-ball
-- data, which is the standard pattern for BI-tool data modeling.
-- ============================================================================

-- View 1: One row per match with derived business fields (batting-first
-- team, win margin type, chase success flag) — this is the primary fact
-- table a Power BI report would build match-level visuals on.
CREATE VIEW vw_match_summary AS
SELECT
    m.id AS match_id,
    m.season,
    m.date,
    m.venue,
    m.city,
    m.team1,
    m.team2,
    m.toss_winner,
    m.toss_decision,
    CASE
        WHEN m.toss_winner = m.team1 AND m.toss_decision = 'bat' THEN m.team1
        WHEN m.toss_winner = m.team1 AND m.toss_decision = 'field' THEN m.team2
        WHEN m.toss_winner = m.team2 AND m.toss_decision = 'bat' THEN m.team2
        WHEN m.toss_winner = m.team2 AND m.toss_decision = 'field' THEN m.team1
    END AS batting_first_team,
    m.winner,
    (m.toss_winner = m.winner) AS toss_winner_won_match,
    m.result,
    m.result_margin,
    m.target_runs,
    m.player_of_match
FROM matches m;

-- View 2: Team-season aggregated performance — the table a "team performance
-- over time" Power BI page would use directly (matches, wins, win %,
-- toss-win rate) without needing to re-derive it from raw matches each time.
CREATE VIEW vw_team_season_summary AS
WITH team_matches AS (
    SELECT season, team1 AS team FROM matches
    UNION ALL
    SELECT season, team2 AS team FROM matches
)
SELECT
    tm.season,
    tm.team,
    COUNT(*) AS matches_played,
    COUNT(*) FILTER (WHERE m.winner = tm.team) AS matches_won,
    ROUND(100.0 * COUNT(*) FILTER (WHERE m.winner = tm.team) / COUNT(*), 1) AS win_pct,
    COUNT(*) FILTER (WHERE m.toss_winner = tm.team) AS tosses_won
FROM team_matches tm
JOIN matches m ON m.season = tm.season
    AND (m.team1 = tm.team OR m.team2 = tm.team)
GROUP BY tm.season, tm.team;

-- View 3: Batter season stats — runs, balls, strike rate, dismissals per
-- batter per season, the core table for any "player performance" Power BI
-- page (season slicer + batter table visual maps directly onto this).
CREATE VIEW vw_batter_season_stats AS
SELECT
    m.season,
    d.batter,
    COUNT(DISTINCT d.match_id) AS innings_played,
    SUM(d.batsman_runs) AS total_runs,
    COUNT(*) FILTER (WHERE d.extras_type IS NULL OR d.extras_type != 'wides') AS balls_faced,
    ROUND(100.0 * SUM(d.batsman_runs) /
        NULLIF(COUNT(*) FILTER (WHERE d.extras_type IS NULL OR d.extras_type != 'wides'), 0), 1) AS strike_rate,
    COUNT(*) FILTER (WHERE d.batsman_runs = 4) AS fours,
    COUNT(*) FILTER (WHERE d.batsman_runs = 6) AS sixes,
    COUNT(*) FILTER (WHERE d.player_dismissed = d.batter) AS dismissals
FROM deliveries d
JOIN matches m ON d.match_id = m.id
GROUP BY m.season, d.batter;

-- View 4: Phase-wise scoring (Powerplay 1-6, Middle 7-15, Death 16-20) —
-- lets Power BI build a phase-comparison visual without recomputing the
-- CASE/bucketing logic in DAX every time.
CREATE VIEW vw_phase_wise_scoring AS
SELECT
    d.match_id,
    m.season,
    d.batting_team,
    CASE
        WHEN d.over < 6 THEN 'Powerplay (1-6)'
        WHEN d.over < 15 THEN 'Middle (7-15)'
        ELSE 'Death (16-20)'
    END AS phase,
    SUM(d.total_runs) AS runs_scored,
    COUNT(*) FILTER (WHERE d.is_wicket = 1) AS wickets_lost,
    COUNT(*) AS balls_bowled
FROM deliveries d
JOIN matches m ON d.match_id = m.id
GROUP BY d.match_id, m.season, d.batting_team,
    CASE WHEN d.over < 6 THEN 'Powerplay (1-6)'
         WHEN d.over < 15 THEN 'Middle (7-15)'
         ELSE 'Death (16-20)' END;
